package JAVA.ASSIGN_2.A2Q1;

public class handleBook{
	
	public static void main(String[] args) {
		handleBook obj = new handleBook();
        // obj.addBook("DSA");
        // obj.addBook("Java");
        // obj.addBook("DBMS");
        // obj.addBook("CN");
        // obj.addBook("OOPS");
        // obj.showInventory();
        // obj.checkOut("DSA");
        // obj.checkOut("CN");
        // obj.showInventory();

        
	}
}
